# `path` for Sketch

All the [nodejs path](https://nodejs.org/api/path.html) API is available.
